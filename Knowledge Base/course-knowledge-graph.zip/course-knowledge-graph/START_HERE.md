# Use this course knowledge graph with your AI

This export contains the SAME built Graphify graph, viewer, report and provenance;
it does not contain the course PDFs, Office files or videos. It is local/offline.

## Where to put it

Unzip `course-knowledge-graph.zip` into your `Knowledge Base` folder, so you have:

```
Knowledge Base/
  Courses/
    extracted/
      Motor_Drive_Systems_ELEN6909/...
      MEMS_Sensors_MECE4214E/...
      Mechatronics_E4058/...
  course-knowledge-graph/
    START_HERE.md
    query_graph.py
    setup.py
    graphify-out/graph.json
    graphify-out/graph.html
```

If you have only the three original ZIPs in `Courses/`, first run:

```
python3 course-knowledge-graph/unpack_courses.py --root .
```

From your `Knowledge Base` folder, verify the exact source files and bind paths:

```
python3 course-knowledge-graph/setup.py --root .
```

Python 3.9+ is sufficient for the portable scripts; no packages or API key needed.
The setup checks every source referenced by the graph against SHA-256 hashes and
never modifies the course documents. Different or missing files are reported.

## Prompt to give your AI

> Read `course-knowledge-graph/START_HERE.md`. Use its existing course knowledge
> graph to answer my questions; do not rebuild it. My source root is this
> Knowledge Base folder. Run `python3 course-knowledge-graph/query_graph.py
> "MY QUESTION" --root .` for a scoped graph result, then open relevant original
> local course files at the cited pages to verify details. Distinguish EXTRACTED
> source relationships from INFERRED links. Respect the coverage/OCR limitations.

Replace MY QUESTION with your actual question. The AI needs terminal and local
file-reading access. A chat with no file/terminal access cannot navigate your
local sources merely from this ZIP; provide it the returned graph context and
relevant source documents instead.

Examples:

```
python3 course-knowledge-graph/query_graph.py 'How do current and back EMF relate to motor torque?' --root .
python3 course-knowledge-graph/query_graph.py 'What connects ADC sampling, filtering and sensor noise?' --root .
```

The portable script performs deterministic keyword/BFS retrieval, not LLM answer
generation. An AI can also read graph.json directly (NetworkX node-link format;
relationships are in `links`, with `source` and `target` node IDs).

For Graphify's richer CLI, optionally install the official `graphifyy` package,
then use `graphify query "QUESTION" --graph course-knowledge-graph/graphify-out/graph.json`.
The original build used Graphify 0.9.112; installation is not required to use this
portable export. Open graphify-out/graph.html for search/click/filter navigation;
its JavaScript dependency is included, so the viewer works offline.

## What is covered

The graph has 1,119 nodes and 1,689 directed connections across Motor Drive
Systems, MEMS Sensors and Sensing, and Mechatronics. 95 unique document text/OCR
conversions were read completely; five long reference manuals/books have
contents/section indexes only. Eight byte-identical educational copies are
linked through their canonical sources. Check graphify-out/coverage.json.
Tutorials have sampled visual frames; one includes an instructional audio
transcript. Full video/frame-by-frame coverage is not claimed.

Machine OCR can misread handwriting, equations and figures; source pages remain
the authority. EXTRACTED indicates a relationship explicit in the reviewed text,
not a validated equation. Cross-course theme links are INFERRED. Course editions
include historical material; do not treat old rosters or component sheets as
current project assignments or verified hardware settings.

No original course files or extracted working text are bundled. The original
Graphify report and fragments' coverage limitations are preserved. Token usage
was unavailable from the host session and is not asserted as zero.
