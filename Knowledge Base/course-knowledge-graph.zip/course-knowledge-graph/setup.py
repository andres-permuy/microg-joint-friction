#!/usr/bin/env python3
"""Bind the portable graph to matching local course files and verify hashes."""
import argparse,json,hashlib
from pathlib import Path
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=BASE.parent);a=p.parse_args();root=a.root.resolve()
m=json.loads((BASE/'source_manifest.json').read_text());missing=[];different=[]
for row in m['files']:
 f=root/row['path']
 if not f.is_file():missing.append(row['path']);continue
 if hashlib.sha256(f.read_bytes()).hexdigest()!=row['sha256']:different.append(row['path'])
graph=BASE/'graphify-out/graph.json'
assert hashlib.sha256(graph.read_bytes()).hexdigest()==m['graph_sha256'],'Graph checksum mismatch'
print(f'Checked {len(m["files"])} source files. Missing: {len(missing)}; different: {len(different)}.')
if missing or different:
 print(json.dumps({'missing':missing,'different':different},indent=2));print('If you have the original ZIPs instead, run unpack_courses.py --root PATH first.');raise SystemExit(1)
(BASE/'graphify-out/.graphify_root').write_text(str(root))
print('Verified source root:',root);print('Ready. Read START_HERE.md and query with query_graph.py or Graphify.')
