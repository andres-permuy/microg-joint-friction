#!/usr/bin/env python3
"""Optional: reproduce the source layout from the three original course ZIPs."""
import argparse,zipfile,io
from pathlib import Path
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=BASE.parent);a=p.parse_args();courses=a.root.resolve()/'Courses'
def unpack(z,dest):
 for item in z.infolist():
  rel=Path(item.filename)
  if item.is_dir() or '__MACOSX' in rel.parts or rel.name.startswith('._'):continue
  if rel.is_absolute() or '..' in rel.parts or item.file_size>1024**3:raise ValueError('Unsafe archive member')
  target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);b=z.read(item)
  if target.exists():
   if target.read_bytes()!=b:raise ValueError(f'Existing different file, refusing overwrite: {target}')
  else:target.write_bytes(b)
  if rel.suffix.lower()=='.zip':
   with zipfile.ZipFile(io.BytesIO(b)) as nested:unpack(nested,target.with_suffix(''))
for prefix,name in [('ELEN 6909_','Motor_Drive_Systems_ELEN6909'),('MECE4214E_','MEMS_Sensors_MECE4214E'),('course_files_export.zip','Mechatronics_E4058')]:
 candidates=list(courses.glob(prefix+'*')) if not prefix.endswith('.zip') else [courses/prefix]
 candidates=[f for f in candidates if f.is_file() and f.suffix.lower()=='.zip']
 if len(candidates)!=1:raise ValueError(f'Expected exactly one original archive matching {prefix} in {courses}')
 with zipfile.ZipFile(candidates[0]) as z:unpack(z,courses/'extracted'/name)
 print('Prepared',name)
