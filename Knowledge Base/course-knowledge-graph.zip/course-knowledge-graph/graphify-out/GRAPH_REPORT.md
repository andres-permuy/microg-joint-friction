# Graph Report - Knowledge Base  (2026-11-18)

## Corpus Check
- 102 files · ~661,958 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1119 nodes · 1689 edges · 75 communities
- Extraction: 78% EXTRACTED · 22% INFERRED · 0% AMBIGUOUS · INFERRED: 373 edges (avg confidence: 0.86)
- Token usage: unavailable from this host session; no separate LLM API was called.

## Community Hubs (Navigation)
- C1_Motor Drive Systems -T1_Intro / C2_Motor Drive Systems -T2_Mechatronics
- Case Study #1 Parts (Complete DataSheets) / 02_Lecture # 2 - Digital Logic Case Study
- C7 (2^ Part)_Motor Drive Systems -T4_IPM and RSyM drives / C3_Motor Drive Systems -T3_Brushed DC Motors (DCM)
- Calibration and measurement / Nachtigal reading — Wheatstone bridges
- Nachtigal/Ott reading — grounding and cabling techniques / Noise and signal integrity
- Embedded assembly and C software standard / Lecture # 5 - On - Off Control Case Study
- Switching and motor power / Case Study #4 - Stepper Motors
- C5&C6 (1^ Part)_Motor Drive Systems -T4_PM synchronous motors (PMSM) / C5&C6 (2^ Part)_Motor Drive Systems -T4_PM synchronous motors (PMSM)
- C10_Motor Drive Systems -T5_Induction motor - vector control / C11_Motor Drive Systems -T6_Sensorless high speed PMSM drives
- LFx5x JFET Input Operational Amplifiers datasheet (Rev. D) / AS358_358A_358B
- Keysight InfiniiVision 2000 X-Series Oscilloscopes Users Guide / Acquisition Control
- Motor Drive Systems — ELEN 6909 / C8_Motor Drive Systems -T5_Induction motors modeling
- Exercise 3 — introduction to embedded C / Lecture # 7 - State Machines _ Embedded C Programming
- MicroChip MPLAB IDE Users Guide / A Basic Tutorial for MPLAB IDE
- !! MicroChip PIC16x7x7 Data Sheet (2014) / Addressable Universal Synchronous Asynchronous Receiver Transmitter (AUSART)
- Microfluidics — Spring 2026 lecture / Hydraulic resistance analogy
- MicroChip MPASM Assembler / Assembler Examples, Tips and Tricks
- Exercise 1 — laboratory equipment and comparator prototyping / Amplitude measurement
- Analog filtering / Analog filter lecture calculations — corrected and obsolete worksheets
- 15mH_Inductor_datasheet / Inductor1MH_Datasheet
- Exercise 2 — microcomputer development with MPLAB / Embedded development workflow
- Sampling and conversion / Analog-to-digital conversion
- C9_Motor Drive Systems -T5_Induction motors-sinux steady state and V-f control / Slip and slip angular frequency
- PCB 121A44 ICP pressure sensor manual and certification bundle / 121A44 pressure sensor
- MEMS Sensors and Sensing — MECE4214E / Analog filtering notes — handwritten 2025 OCR
- PIC16F737 processor include-file reference / PIC GPIO direction and pin multiplexing
- Introduction to MicroChip Microcontrollers / Harvard microcontroller architecture
- MPLAB X guide for Exercise 2 and case study 3 / MPLAB PM3 Universal Device Programmer
- Case Study #2 - Analog Electronics - Part 2 of 2 / HowStuffWorks Maglev Trains
- Hoeschele ADC textbook — Chapter 1 conversion systems / Quantization error
- MAX7480 switched-capacitor filter datasheet / Butterworth filter
- Hoeschele ADC textbook — Chapter 2 part 1 / Aperture jitter
- Lecture # 1 - Course Introduction / Integrated mechatronic design
- Lecture # 3A - Electrical System Dynamics - Passive & Active Circuits / Magnetic levitation feedback
- Semiconductors / Bipolar transistors
- Nachtigal reading — operational and instrumentation amplifiers / Operational amplifier
- Mechatronics & Embedded Microcomputer Control (ME E4058) / Calendar_Fall_2024
- Case Study #2 - Analog Electronics - Part 1 of 2 / Input-output impedance and loading
- Lecture # 4 - Introduction to MicroControllers / Instruction pipelining and timing
- Digital integrated circuits / Combinational logic circuits
- Photonic semiconductors / Light
- This Maglev Heart Could Keep Cardiac Patients Alive - IEEE Spectrum / Active magnetic bearing position control
- MicroChip PIC16x7x7 Assembly (2014) / PIC16F7X7 instruction-set reference
- February 23 ADC boardwork — handwritten OCR / Resolution-speed tradeoff
- Analog-to-digital conversion lecture — Spring 2026 / Quantization error
- Wobschall textbook — active filters / Active differentiator
- Keysight InfiniiVision 2000 X-Series Oscilloscopes Data Sheet / Oscilloscope phase convention
- QW-BG015 1N5400-G Thru. 1N5408-G RevA / 1N5400 to 1N5408 rectifier family
- Electronic components / Capacitors
- Robert Rose guest lecture — MEMS in consumer electronics / Accelerometer
- Signal conditioner notes — handwritten 2026 OCR / Common-mode rejection
- Amplification lecture — Spring 2025 / Current-loop transmission
- syllabus_e4058 / Integrated mechatronic design
- BodeStepPZDiffEq / Generalized electrical impedance
- MPLAB X guide for case study 4 / Device programming
- 100 electronic circuits / Comparator circuits
- Electricity / Alternating current electricity
- Getting Started in Electronics — visual contents index / Circuit assembly tips
- Analog filtering lecture — Spring 2026 / Active band-pass filter
- ADC conversion notes — handwritten 2026 OCR / Aperture time
- Lecture # 3B - Electrical System Dynamics - AC Impedance / Levitation sensor calibration
- Linear integrated circuits / Operational amplifiers
- Amplifiers and conditioning / Instrumentation amplifier
- headless libre login / BME280 Python dependency
- Course Rules Fall 2024 / Fall 2024 lab safety and storage
- PIC ADC registers / Sample-and-hold acquisition
- Case Study #2 - Analog Electronics AnswerSheet_with_pts / Analog circuit analysis worksheet
- Flash ADC / Flash ADC
- Integrating ADC / Integrating ADC
- Flashing SD Card / USBImager
- Lab Teams - Case Study 1 / Digital logic group 1
- Lab Teams - Case Study 3 / On-off control group 1
- Lab Teams - Exercise 1 / Exercise 1 group 6
- Lecture # 8 - Stepper Motor Case Study - Animations / Resonance animation label
- Case Study #4 - stepper motors AnswerSheet_with_pts / Stepper dynamic-response assessment

## God Nodes (most connected - your core abstractions)
1. `Mechatronics & Embedded Microcomputer Control (ME E4058)` - 55 edges
2. `Sampling and conversion` - 26 edges
3. `MEMS Sensors and Sensing — MECE4214E` - 25 edges
4. `Keysight InfiniiVision 2000 X-Series Oscilloscopes Users Guide` - 24 edges
5. `Analog filtering` - 23 edges
6. `Calibration and measurement` - 22 edges
7. `MicroChip MPLAB IDE Users Guide` - 21 edges
8. `Hoeschele ADC textbook — Chapter 2 part 1` - 20 edges
9. `!! MicroChip PIC16x7x7 Data Sheet (2014)` - 20 edges
10. `Case Study #1 Parts (Complete DataSheets)` - 20 edges

## Surprising Connections (you probably didn't know these)
- `Sampling and conversion` --conceptually_related_to--> `ADC architectures`  [INFERRED]
  graphify/cross_course_links.json → Courses/extracted/Mechatronics_E4058/02 Lectures/L06/Lecture # 6 - A to D Converters.pdf
- `Sampling and conversion` --conceptually_related_to--> `Sampling and quantization`  [INFERRED]
  graphify/cross_course_links.json → Courses/extracted/Mechatronics_E4058/02 Lectures/L06/Lecture # 6 - A to D Converters.pdf
- `Sampling and conversion` --conceptually_related_to--> `Analog-to-digital conversion`  [INFERRED]
  graphify/cross_course_links.json → Courses/extracted/Mechatronics_E4058/03 Lab Exercises/Exercise #2 - Microcomputer Development System/p16f737 Include File.pdf
- `Analog filtering` --conceptually_related_to--> `Second-order damping and filters`  [INFERRED]
  graphify/cross_course_links.json → Courses/extracted/Mechatronics_E4058/02 Lectures/L03/BodeStepPZDiffEq.pdf
- `Analog filtering` --conceptually_related_to--> `First-order active low-pass conditioning`  [INFERRED]
  graphify/cross_course_links.json → Courses/extracted/Mechatronics_E4058/04 Case Studies/CS02/Case Study #2 - Analog Electronics - Part 1 of 2.pdf

## Communities (75 total, 0 thin omitted)

### Community 0 - "C1_Motor Drive Systems -T1_Intro / C2_Motor Drive Systems -T2_Mechatronics"
Cohesion: 0.05
Nodes (65): First-order step and Bode response, Lead-lag compensation, Thermostat on-off feedback mode, AC heater power control, Lecture # 9 -Thermal Systems Case Study, First-order thermal transfer function, Lumped thermal modeling assumptions, Semiconductor temperature sensing (+57 more)

### Community 1 - "Case Study #1 Parts (Complete DataSheets) / 02_Lecture # 2 - Digital Logic Case Study"
Cohesion: 0.05
Nodes (57): Boolean combinational logic, Comparator threshold detection, Digital interlocks and glue logic, 02_Lecture # 2 - Digital Logic Case Study, Eight-state timing circuit, Flip-flops and state storage, Hall-effect magnetic sensing, Karnaugh logic minimization (+49 more)

### Community 2 - "C7 (2^ Part)_Motor Drive Systems -T4_IPM and RSyM drives / C3_Motor Drive Systems -T3_Brushed DC Motors (DCM)"
Cohesion: 0.06
Nodes (57): PI anti-windup, Torque reference saturation, Armature voltage balance, Armature voltage speed control, Back electromotive force, Brushed DC motor, DC motor dynamic poles, DC motor time constants (+49 more)

### Community 3 - "Calibration and measurement / Nachtigal reading — Wheatstone bridges"
Cohesion: 0.05
Nodes (56): ADC architectures, ADC conversion errors, Aliasing and antialias filtering, Analog signal conditioning, Calibration lookup and polynomial linearization, Lecture # 6 - A to D Converters, Input-referred code width, Interrupt service and context saving (+48 more)

### Community 4 - "Nachtigal/Ott reading — grounding and cabling techniques / Noise and signal integrity"
Cohesion: 0.06
Nodes (47): Flicker noise, Equivalent noise bandwidth, ADC AC signal-to-noise addendum — handwritten OCR, Quantization noise, Signal-to-noise ratio, ADC signal-to-noise AC and DC worksheet, Quantization noise, Signal-to-noise ratio (+39 more)

### Community 5 - "Embedded assembly and C software standard / Lecture # 5 - On - Off Control Case Study"
Cohesion: 0.05
Nodes (46): Bit masks and carry-aware rotation, Lecture # 5 - On - Off Control Case Study, Firmware process and code inspection, On-off control versus switching, Potentiometer ADC scaling and timing, Reusable embedded routines, Solenoid fault recovery state machine, Solenoid magnetic force and duty limits (+38 more)

### Community 6 - "Switching and motor power / Case Study #4 - Stepper Motors"
Cohesion: 0.07
Nodes (43): Bipolar H-bridge current control, Lecture # 8 - Stepper Motor Case Study, Microstepping current modulation, Pull-in and pull-out torque, Stepper motor magnetic types, Stepper position by pulse count, Stepper resonance and damping, Unipolar switching and flyback diodes (+35 more)

### Community 7 - "C5&C6 (1^ Part)_Motor Drive Systems -T4_PM synchronous motors (PMSM) / C5&C6 (2^ Part)_Motor Drive Systems -T4_PM synchronous motors (PMSM)"
Cohesion: 0.08
Nodes (42): Angle and current compensation, Cross-axis inductance estimation bias, C12_Motor Drive Systems -T6_Sensorless zero-low speed IPMSM&RSM drives, HF demodulation and position observer, HF signal separation, High-frequency voltage injection, Incremental inductance maps, Inductance saliency position information (+34 more)

### Community 8 - "C10_Motor Drive Systems -T5_Induction motor - vector control / C11_Motor Drive Systems -T6_Sensorless high speed PMSM drives"
Cohesion: 0.12
Nodes (33): Current-model rotor flux estimator, C10_Motor Drive Systems -T5_Induction motor - vector control, Field orientation versus MTPA, Flux-producing direct current, Indirect field-oriented control, Induction motor speed estimation, Integrator drift and initial-condition error, Loss of field orientation (+25 more)

### Community 9 - "LFx5x JFET Input Operational Amplifiers datasheet (Rev. D) / AS358_358A_358B"
Cohesion: 0.11
Nodes (27): AS358 analog application circuits, AS358 common-mode and swing limits, AS358 current source and sink asymmetry, AS358 dual operational amplifier, AS358 offset and bias error, AS358 package thermal resistance, AS358 quiescent supply current, AS358 single-supply operation (+19 more)

### Community 10 - "Keysight InfiniiVision 2000 X-Series Oscilloscopes Users Guide / Acquisition Control"
Cohesion: 0.08
Nodes (25): Acquisition Control, CAN/LIN Triggering and Serial Decode, Cursors, Digital Channels, Digital Voltmeter, Display Settings, Keysight InfiniiVision 2000 X-Series Oscilloscopes Users Guide, Getting Started (+17 more)

### Community 11 - "Motor Drive Systems — ELEN 6909 / C8_Motor Drive Systems -T5_Induction motors modeling"
Cohesion: 0.17
Nodes (24): Cage rotor induction motor, C8_Motor Drive Systems -T5_Induction motors, Fifth-order electromechanical model, Four-parameter dynamic equivalent circuit, Induction motor flux-current relations, Induction motor modeling hypotheses, Induction motor power balance, Magnetizing current (+16 more)

### Community 12 - "Exercise 3 — introduction to embedded C / Lecture # 7 - State Machines _ Embedded C Programming"
Cohesion: 0.09
Nodes (22): Mealy and Moore machines, Boolean and bitwise C operations, C control flow for modes, C functions scope and pointers, Lecture # 7 - State Machines _ Embedded C Programming, Embedded C types and memory, Hierarchical modes and fault states, Mealy and Moore machines (+14 more)

### Community 13 - "MicroChip MPLAB IDE Users Guide / A Basic Tutorial for MPLAB IDE"
Cohesion: 0.09
Nodes (22): A Basic Tutorial for MPLAB IDE, Additional Features, MicroChip MPLAB IDE Users Guide, External Memory Handling, Getting Started with MPLAB SIM, Integrated Language Tools, Integrated Software/Hardware Tools, MPLAB IDE Desktop (+14 more)

### Community 14 - "!! MicroChip PIC16x7x7 Data Sheet (2014) / Addressable Universal Synchronous Asynchronous Receiver Transmitter (AUSART)"
Cohesion: 0.10
Nodes (21): Addressable Universal Synchronous Asynchronous Receiver Transmitter (AUSART), Analog-to-Digital Converter (A/D) Module, Capture/Compare/PWM Modules, Comparator Module, Comparator Voltage Reference Module, DC and AC Characteristics Graphs and Tables, Development Support, Device Overview (+13 more)

### Community 15 - "Microfluidics — Spring 2026 lecture / Hydraulic resistance analogy"
Cohesion: 0.12
Nodes (20): Aptamers and SELEX, Channel materials and bonding, Continuum flow and Knudsen number, Microfluidics — Spring 2026 lecture, Fluorescent affinity sensing, Hagen-Poiseuille flow, Hydraulic resistance analogy, Laminar flow and Reynolds number (+12 more)

### Community 16 - "MicroChip MPASM Assembler / Assembler Examples, Tips and Tricks"
Cohesion: 0.11
Nodes (18): Assembler Examples, Tips and Tricks, Assembler Interfaces, Directives, MicroChip MPASM Assembler, Errors, Errors, Warnings and Common Problems, Errors, Warnings, Messages, and Limitations, Expression Syntax and Operation (+10 more)

### Community 17 - "Exercise 1 — laboratory equipment and comparator prototyping / Amplitude measurement"
Cohesion: 0.12
Nodes (17): Amplitude measurement, Comparator applications, Comparator response time, Comparator strobe, DC power supply, Digital multimeter, Exercise 1 — laboratory equipment and comparator prototyping, Function generator (+9 more)

### Community 18 - "Analog filtering / Analog filter lecture calculations — corrected and obsolete worksheets"
Cohesion: 0.20
Nodes (17): Cutoff frequency, Analog filter lecture calculations — corrected and obsolete worksheets, Filter time-domain response, Obsolete filter calculation, RC low-pass filter, Analog filter, RC low-pass filter, Analog filter (+9 more)

### Community 19 - "15mH_Inductor_datasheet / Inductor1MH_Datasheet"
Cohesion: 0.19
Nodes (16): Bourns 1140 high-current choke series, Choke inductance tolerance, Choke insulation and temperature, Choke RMS and saturation current, Choke winding DC resistance, 15mH_Inductor_datasheet, Fifteen-millihenry choke, Radial choke mechanical mounting (+8 more)

### Community 20 - "Exercise 2 — microcomputer development with MPLAB / Embedded development workflow"
Cohesion: 0.14
Nodes (14): Embedded development workflow, Breakpoint debugging, Configuration bits, Exercise 2 — microcomputer development with MPLAB, GPIO initialization, MPASM assembler, MPLAB IDE, MPLAB simulator (+6 more)

### Community 21 - "Sampling and conversion / Analog-to-digital conversion"
Cohesion: 0.23
Nodes (14): Analog-to-digital conversion, Analog-to-digital conversion, Nyquist sampling, Analog-to-digital conversion, Nyquist sampling, Sample-and-hold circuit, ADC resolution, ADC resolution (+6 more)

### Community 22 - "C9_Motor Drive Systems -T5_Induction motors-sinux steady state and V-f control / Slip and slip angular frequency"
Cohesion: 0.25
Nodes (14): Motor power losses, C9_Motor Drive Systems -T5_Induction motors-sinux steady state and V-f control, High-frequency voltage limitation, Induction motor power flow, Induction motor sinusoidal steady state, Resistive voltage-drop compensation, Rotor-flux scalar control, Rotor power and torque (+6 more)

### Community 23 - "PCB 121A44 ICP pressure sensor manual and certification bundle / 121A44 pressure sensor"
Cohesion: 0.18
Nodes (13): 121A44 pressure sensor, Conformity documentation, Constant-current excitation, PCB 121A44 ICP pressure sensor manual and certification bundle, Dynamic pressure response, Intrinsic safety certification, Non-sparking certification, Piezoelectric sensing (+5 more)

### Community 24 - "MEMS Sensors and Sensing — MECE4214E / Analog filtering notes — handwritten 2025 OCR"
Cohesion: 0.18
Nodes (12): MEMS Sensors and Sensing — MECE4214E, April 6 analog filtering boardwork — handwritten OCR, Filter phase shift, Analog Filtering Notes 2026 [identical copy], Bessel filter, Analog filtering notes — handwritten 2025 OCR, Filter design tradeoffs, Filter order (+4 more)

### Community 25 - "PIC16F737 processor include-file reference / PIC GPIO direction and pin multiplexing"
Cohesion: 0.18
Nodes (12): PIC GPIO direction and pin multiplexing, PIC memory banks and STATUS, Analog-to-digital conversion, Configuration bits, PIC16F737 processor include-file reference, GPIO ports, Interrupt control, Memory map (+4 more)

### Community 26 - "Introduction to MicroChip Microcontrollers / Harvard microcontroller architecture"
Cohesion: 0.18
Nodes (11): Harvard microcontroller architecture, PIC program and indirect data addressing, Introduction to MicroChip Microcontrollers, Harvard memory and register banks, Multiple precision carry propagation, PIC16F84 integrated microcontroller, PIC instruction operands and addressing, PIC subtraction and comparisons (+3 more)

### Community 27 - "MPLAB X guide for Exercise 2 and case study 3 / MPLAB PM3 Universal Device Programmer"
Cohesion: 0.18
Nodes (11): Device programming, MPLAB X guide for Exercise 2 and case study 3, MPASM assembler, MPLAB X IDE, PIC16F737, PM3 programmer, Project build, Using MPLAB X for Exercise 2 and case study 3 [identical copy] (+3 more)

### Community 28 - "Case Study #2 - Analog Electronics - Part 2 of 2 / HowStuffWorks Maglev Trains"
Cohesion: 0.20
Nodes (11): Case Study #2 - Analog Electronics - Part 2 of 2, Hall sensor polarity calibration, Inductor drive protection, Lead-compensated permanent-magnet levitation, Maglev threshold control demonstration, Magnetic levitation component chain, HowStuffWorks Maglev Trains, Electromagnetic and electrodynamic suspension (+3 more)

### Community 29 - "Hoeschele ADC textbook — Chapter 1 conversion systems / Quantization error"
Cohesion: 0.18
Nodes (11): Quantization error, Closed-loop temperature control, Converter system requirements, Digital-to-analog conversion, Hoeschele ADC textbook — Chapter 1 conversion systems, Error budget, Noise-limited dynamic range, Quantization error (+3 more)

### Community 30 - "MAX7480 switched-capacitor filter datasheet / Butterworth filter"
Cohesion: 0.24
Nodes (11): Anti-aliasing filter, Butterworth filter, Clock feedthrough, Clock synchronization, Clock-tunable cutoff, Common-mode bias, MAX7480 switched-capacitor filter datasheet, Input impedance (+3 more)

### Community 31 - "Hoeschele ADC textbook — Chapter 2 part 1 / Aperture jitter"
Cohesion: 0.18
Nodes (11): Aperture jitter, Charge-balancing ADC, Converter architecture selection, Direct-comparison ADC, Hoeschele ADC textbook — Chapter 2 part 1, Dual-slope ADC, Equivalent-time subsampling, Pipelined sample acquisition (+3 more)

### Community 32 - "Lecture # 1 - Course Introduction / Integrated mechatronic design"
Cohesion: 0.20
Nodes (10): Assembly and C tradeoffs, Design knowledge toolbox and parts kit, Lecture # 1 - Course Introduction, Embedded real-time correctness, Integrated mechatronic design, Laboratory comparator experiment, Mixed-signal instrumentation, Open-ended hardware case studies (+2 more)

### Community 33 - "Lecture # 3A - Electrical System Dynamics - Passive & Active Circuits / Magnetic levitation feedback"
Cohesion: 0.24
Nodes (10): Lecture # 3A - Electrical System Dynamics - Passive & Active Circuits, Kirchhoff laws and dividers, Levitation model limitations, Magnetic bearing versus suspension, Magnetic inductance and reluctance, Magnetic levitation feedback, Methodical circuit debugging, Op-amp gain and analog PID circuits (+2 more)

### Community 34 - "Semiconductors / Bipolar transistors"
Cohesion: 0.20
Nodes (10): Bipolar transistors, Field-effect transistors, Semiconductors, Silicon, Silicon-controlled rectifiers, The diode, The transistor, The unijunction transistor (+2 more)

### Community 35 - "Nachtigal reading — operational and instrumentation amplifiers / Operational amplifier"
Cohesion: 0.24
Nodes (10): Bias-current return path, Nachtigal reading — operational and instrumentation amplifiers, Input bias current, Input offset voltage, Negative feedback, Operational amplifier, Settling time, Shot noise (+2 more)

### Community 36 - "Mechatronics & Embedded Microcomputer Control (ME E4058) / Calendar_Fall_2024"
Cohesion: 0.22
Nodes (9): Calendar_Fall_2024, Fall 2024 case-study deadlines, Fall 2024 instructional sequence, Lab_Rules, Laboratory collaboration, Analog electronics group 1, Lab Teams - Case Study 2 - updated 9-25-2024, Updated analog electronics roster (+1 more)

### Community 37 - "Case Study #2 - Analog Electronics - Part 1 of 2 / Input-output impedance and loading"
Cohesion: 0.22
Nodes (9): Input-output impedance and loading, Active integrator and differentiator, Analog prototyping verification, Buffer isolation and circuit loading, Case Study #2 - Analog Electronics - Part 1 of 2, First-order active low-pass conditioning, Inverting gain level shift and trimming, Passive filter experimental modeling (+1 more)

### Community 38 - "Lecture # 4 - Introduction to MicroControllers / Instruction pipelining and timing"
Cohesion: 0.25
Nodes (9): Lecture # 4 - Introduction to MicroControllers, Instruction pipelining and timing, Number systems and binary data, PIC assembler and instruction set, PIC peripherals, Subroutines and stack, Switch debouncing, Button debounce (+1 more)

### Community 39 - "Digital integrated circuits / Combinational logic circuits"
Cohesion: 0.22
Nodes (9): Combinational logic circuits, Data highways, Digital IC families, Digital integrated circuits, Diode gates, Gate symbols, Sequential logic circuits, The binary connection (+1 more)

### Community 40 - "Photonic semiconductors / Light"
Cohesion: 0.22
Nodes (9): Light, Light-emitting diodes, Optical components, Photodiodes, Photonic semiconductors, Photoresistive light detectors, Photothyristors, Phototransistors (+1 more)

### Community 41 - "This Maglev Heart Could Keep Cardiac Patients Alive - IEEE Spectrum / Active magnetic bearing position control"
Cohesion: 0.28
Nodes (9): 2019 artificial-heart development snapshot, Active magnetic bearing position control, Axial rotor hydraulic balancing, Bivacor dual-sided centrifugal rotor, Blood clearance and washout, This Maglev Heart Could Keep Cardiac Patients Alive - IEEE Spectrum, Pulsatile flow from speed modulation, Rapid prototyping and mock circulation testing (+1 more)

### Community 42 - "MicroChip PIC16x7x7 Assembly (2014) / PIC16F7X7 instruction-set reference"
Cohesion: 0.39
Nodes (9): Conditional skip instructions, MicroChip PIC16x7x7 Assembly (2014), PIC16F7X7 instruction-set reference, PIC bit manipulation, PIC read-modify-write port behavior, PIC status-flag effects, PIC subroutine and interrupt returns, PIC watchdog and sleep controls (+1 more)

### Community 43 - "February 23 ADC boardwork — handwritten OCR / Resolution-speed tradeoff"
Cohesion: 0.22
Nodes (9): February 23 ADC boardwork — handwritten OCR, Noise rejection, Successive-approximation ADC, Resolution-speed tradeoff, Successive-approximation ADC, Resolution-speed tradeoff, Successive-approximation ADC, Resolution-speed tradeoff (+1 more)

### Community 44 - "Analog-to-digital conversion lecture — Spring 2026 / Quantization error"
Cohesion: 0.28
Nodes (9): Aperture time, Delta-sigma ADC, Analog-to-digital conversion lecture — Spring 2026, Multistep ADC, Quantization error, Sample-and-hold circuit, Voltage-to-frequency conversion, Delta-sigma ADC (+1 more)

### Community 45 - "Wobschall textbook — active filters / Active differentiator"
Cohesion: 0.22
Nodes (9): Active differentiator, Active integrator, Chebyshev filter, Wobschall textbook — active filters, Elliptic filter, Notch filter, Sallen-Key filter, State-variable filter (+1 more)

### Community 46 - "Keysight InfiniiVision 2000 X-Series Oscilloscopes Data Sheet / Oscilloscope phase convention"
Cohesion: 0.25
Nodes (8): Phase measurement, Oscilloscope phase convention, Keysight InfiniiVision 2000 X-Series Oscilloscopes Data Sheet, Integrated signal generation and decode, Mixed-signal scope acquisition envelope, Probe loading and operating limits, Triggering and acquisition modes, Waveform measurements and export

### Community 47 - "QW-BG015 1N5400-G Thru. 1N5408-G RevA / 1N5400 to 1N5408 rectifier family"
Cohesion: 0.36
Nodes (8): 1N5400 to 1N5408 rectifier family, Diode cathode band, QW-BG015 1N5400-G Thru. 1N5408-G RevA, Forward voltage and conduction loss, Rectifier reverse-voltage selection, Rectifier thermal derating, Reverse leakage temperature dependence, Surge current versus continuous current

### Community 48 - "Electronic components / Capacitors"
Cohesion: 0.25
Nodes (8): Capacitors, Coils, Electronic components, Relays, Resistors, Switches, Transformers, Wire and cable

### Community 49 - "Robert Rose guest lecture — MEMS in consumer electronics / Accelerometer"
Cohesion: 0.25
Nodes (8): Accelerometer, Robert Rose guest lecture — MEMS in consumer electronics, ENS160 gas sensor, Gyroscope, MEMS consumer electronics, MEMS microphone, Microphone packaging, Sensor enclosure integration

### Community 50 - "Signal conditioner notes — handwritten 2026 OCR / Common-mode rejection"
Cohesion: 0.25
Nodes (8): ADC input scaling, Common-mode rejection, Signal conditioner notes — handwritten 2026 OCR, Negative feedback, Common-mode rejection, Negative feedback, Signal Conditioner Notes 2025 [identical copy], Common-mode rejection

### Community 51 - "Amplification lecture — Spring 2025 / Current-loop transmission"
Cohesion: 0.25
Nodes (8): Current-loop transmission, Analog design tradeoffs, Body effect, Channel-length modulation, Current-loop transmission, Amplification lecture — Spring 2025, MOSFET, Sensor signal conditioning

### Community 52 - "syllabus_e4058 / Integrated mechatronic design"
Cohesion: 0.33
Nodes (7): Case-study assessment, Course prerequisites, syllabus_e4058, Dynamic modeling and experimentation, Integrated mechatronic design, Lecture-laboratory integration, Real-time embedded programming

### Community 53 - "BodeStepPZDiffEq / Generalized electrical impedance"
Cohesion: 0.29
Nodes (7): BodeStepPZDiffEq, Equivalent dynamic-system representations, First-order pole and time constant, Second-order damping and filters, Generalized electrical impedance, Laplace transfer functions, AC phasors and complex impedance

### Community 54 - "MPLAB X guide for case study 4 / Device programming"
Cohesion: 0.29
Nodes (7): Device programming, MPLAB X guide for case study 4, Embedded C, MPLAB X IDE, PIC16F747, PM3 programmer, XC8 compiler

### Community 55 - "100 electronic circuits / Comparator circuits"
Cohesion: 0.29
Nodes (7): 100 electronic circuits, Comparator circuits, Digital IC circuits, Diode circuits, Linear IC circuits, Photonic circuits, Transistor circuits

### Community 56 - "Electricity / Alternating current electricity"
Cohesion: 0.29
Nodes (7): Alternating current electricity, Direct current electricity, Electrical circuits, Electrical current, Electricity, Pulses, waves, signals and noise, Static electricity

### Community 57 - "Getting Started in Electronics — visual contents index / Circuit assembly tips"
Cohesion: 0.29
Nodes (7): Circuit assembly tips, Getting Started in Electronics — visual contents index, How to solder, Integrated circuits, Permanent circuits, Powering electronic circuits, Temporary circuits

### Community 58 - "Analog filtering lecture — Spring 2026 / Active band-pass filter"
Cohesion: 0.29
Nodes (7): Active band-pass filter, Active versus passive filters, Analog filtering lecture — Spring 2026, Passband ripple, Transition band, Active band-pass filter, Active band-pass filter

### Community 59 - "ADC conversion notes — handwritten 2026 OCR / Aperture time"
Cohesion: 0.29
Nodes (7): Aperture time, ADC conversion notes — handwritten 2026 OCR, Effective number of bits, Pipelined ADC, Timing synchronization, AtoD Notes 2026 [identical copy], Aperture time

### Community 60 - "Lecture # 3B - Electrical System Dynamics - AC Impedance / Levitation sensor calibration"
Cohesion: 0.33
Nodes (6): Lecture # 3B - Electrical System Dynamics - AC Impedance, Levitation sensor calibration, Levitation small-signal linearization, Op-amp operating limits, Real passive component nonidealities, Sense-resistor current amplifier

### Community 61 - "Linear integrated circuits / Operational amplifiers"
Cohesion: 0.33
Nodes (6): Function generators, Linear integrated circuits, Operational amplifiers, The basic linear circuit, Timers, Voltage regulators

### Community 62 - "Amplifiers and conditioning / Instrumentation amplifier"
Cohesion: 0.53
Nodes (6): Instrumentation amplifier, Operational amplifier, Instrumentation amplifier, Operational amplifier, Instrumentation amplifier, Amplifiers and conditioning

### Community 63 - "headless libre login / BME280 Python dependency"
Cohesion: 0.60
Nodes (6): BME280 Python dependency, headless libre login, FileZilla file transfer, Headless SSH access, Initial State sensor dashboard, Remote Python sensor script

### Community 64 - "Course Rules Fall 2024 / Fall 2024 lab safety and storage"
Cohesion: 0.40
Nodes (5): Case-study submission policy, Course Rules Fall 2024, Fall 2024 lab safety and storage, Fall 2024 participation rules, Laboratory storage and safety

### Community 65 - "PIC ADC registers / Sample-and-hold acquisition"
Cohesion: 0.40
Nodes (5): PIC ADC registers, PIC SAR conversion sequence, Sample-and-hold acquisition, ADC acquisition delay, Polled ADC

### Community 66 - "Case Study #2 - Analog Electronics AnswerSheet_with_pts / Analog circuit analysis worksheet"
Cohesion: 0.50
Nodes (4): Analog circuit analysis worksheet, Case Study #2 - Analog Electronics AnswerSheet_with_pts, Experimental model comparison, Maglev demonstration assessment

### Community 67 - "Flash ADC / Flash ADC"
Cohesion: 0.50
Nodes (4): Flash ADC, Flash ADC, Flash ADC, Flash ADC

### Community 68 - "Integrating ADC / Integrating ADC"
Cohesion: 0.50
Nodes (4): Integrating ADC, Integrating ADC, Integrating ADC, Integrating ADC

### Community 69 - "Flashing SD Card / USBImager"
Cohesion: 0.83
Nodes (4): Flashing SD Card, Image write verification, Raspbian OS image, USBImager

### Community 70 - "Lab Teams - Case Study 1 / Digital logic group 1"
Cohesion: 0.67
Nodes (3): Digital logic group 1, Digital logic team roster, Lab Teams - Case Study 1

### Community 71 - "Lab Teams - Case Study 3 / On-off control group 1"
Cohesion: 0.67
Nodes (3): Lab Teams - Case Study 3, On-off control group 1, On-off control team roster

### Community 72 - "Lab Teams - Exercise 1 / Exercise 1 group 6"
Cohesion: 0.67
Nodes (3): Lab Teams - Exercise 1, Exercise 1 group 6, Exercise 1 team roster

### Community 73 - "Lecture # 8 - Stepper Motor Case Study - Animations / Resonance animation label"
Cohesion: 0.67
Nodes (3): Lecture # 8 - Stepper Motor Case Study - Animations, Resonance animation label, Unipolar and bipolar drive animation labels

### Community 74 - "Case Study #4 - stepper motors AnswerSheet_with_pts / Stepper dynamic-response assessment"
Cohesion: 0.67
Nodes (3): Case Study #4 - stepper motors AnswerSheet_with_pts, Stepper dynamic-response assessment, Stepper fault and application assessment

## Ambiguous Edges - Review These
- `Solenoid case documentation inconsistencies` → `Latched faults and safe outputs`  [AMBIGUOUS]
  Courses/extracted/Mechatronics_E4058/04 Case Studies/CS03/Case Study #3 - On Off Control.pdf · relation: conceptually_related_to
- `Solenoid case documentation inconsistencies` → `PIC octal mode and status interface`  [AMBIGUOUS]
  Courses/extracted/Mechatronics_E4058/04 Case Studies/CS03/Case Study #3 - On Off Control.pdf · relation: conceptually_related_to

## Knowledge Gaps
- **429 isolated node(s):** `Laboratory collaboration`, `Real-time embedded programming`, `Case-study assessment`, `Course prerequisites`, `Lecture-laboratory integration` (+424 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 429 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Signal conditioner notes — handwritten 2026 OCR` connect `Signal conditioner notes — handwritten 2026 OCR / Common-mode rejection` to `Calibration and measurement / Nachtigal reading — Wheatstone bridges`, `Nachtigal/Ott reading — grounding and cabling techniques / Noise and signal integrity`, `Amplification lecture — Spring 2025 / Current-loop transmission`, `PCB 121A44 ICP pressure sensor manual and certification bundle / 121A44 pressure sensor`, `Amplifiers and conditioning / Instrumentation amplifier`?**
  _High betweenness centrality (0.000) - this node is a cross-community bridge._
- **Are the 7 inferred relationships involving `Mechatronics & Embedded Microcomputer Control (ME E4058)` (e.g. with `Exercise 1 — laboratory equipment and comparator prototyping` and `Exercise 2 — microcomputer development with MPLAB`) actually correct?**
  _`Mechatronics & Embedded Microcomputer Control (ME E4058)` has 7 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Laboratory collaboration`, `Real-time embedded programming`, `Case-study assessment` to the rest of the system?**
  _429 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `C1_Motor Drive Systems -T1_Intro / C2_Motor Drive Systems -T2_Mechatronics` be split into smaller, more focused modules?**
  _Cohesion score 0.05480769230769231 - nodes in this community are weakly interconnected._
- **Why does `Lead-compensated permanent-magnet levitation` connect `Case Study #2 - Analog Electronics - Part 2 of 2 / HowStuffWorks Maglev Trains` to `C1_Motor Drive Systems -T1_Intro / C2_Motor Drive Systems -T2_Mechatronics`?**
  _High betweenness centrality (0.000) - this node is a cross-community bridge._

### Low-confidence Hints
_AMBIGUOUS edges — the extractor was unsure. Verify before acting on these._

- **What is the exact relationship between `Solenoid case documentation inconsistencies` and `Latched faults and safe outputs`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **What is the exact relationship between `Solenoid case documentation inconsistencies` and `PIC octal mode and status interface`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
## Coverage and interpretation

- See [coverage.json](coverage.json) for per-document line coverage and media review scope.
- Five long reference books/manuals are indexed by table-of-contents sections; their bodies were not semantically reviewed.
- Scanned notes use local machine OCR. Handwriting, equations and diagrams require checking against the source PDFs. Text extraction is not a visual or mathematical verification.
- Tutorial audio was transcribed locally; five frames per tutorial were reviewed. The SD-card tutorial has no instructional narration indexed. Alternate video encodings are retained in the source inventory.
- Byte-identical educational documents are linked as identical copies; distinct dated versions are preserved.
- Cross-course thematic bridges are reviewer inferences, labeled INFERRED (0.85). Explicit source relationships are EXTRACTED (1.0).
- Administrative rosters are historical course context, not the microgravity project's current team. LMS assets and bundled Windows installers are excluded from course concepts and were not executed.
- The graph supports navigation; it does not validate course equations or authorize hardware operating limits.
