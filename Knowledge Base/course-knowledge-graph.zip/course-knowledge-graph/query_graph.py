#!/usr/bin/env python3
"""Dependency-free scoped retrieval from the shared Graphify graph."""
import argparse,json,re
from pathlib import Path
from collections import defaultdict,deque
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('question');p.add_argument('--root',type=Path,default=BASE.parent);p.add_argument('--limit',type=int,default=25)
a=p.parse_args();root=a.root.resolve();data=json.loads((BASE/'graphify-out/graph.json').read_text())
nodes={n['id']:n for n in data['nodes']};edges=data.get('links',data.get('edges',[]));adj=defaultdict(set)
for e in edges:adj[e['source']].add(e['target']);adj[e['target']].add(e['source'])
stop={'what','how','does','the','and','with','from','for','are','between','that','this','which','into','about','use'}
def terms(s):return {w for w in re.findall(r'\w+',s.lower()) if len(w)>2 and w not in stop}
q=terms(a.question)
if 'adc' in q:q.update(['analog','digital','conversion'])
if 'pid' in q:q.update(['controller','control'])
scored=[]
for nid,n in nodes.items():
 score=5*len(q&terms(n.get('label','')))+len(q&terms(n.get('description','')))
 if score:scored.append((score,nid))
scored.sort(reverse=True)
if not scored:print(json.dumps({'matches':[],'note':'No keyword matches; inspect graph vocabulary or try Graphify query.'}));raise SystemExit(4)
selected=set(n for _,n in scored[:min(8,a.limit)]);queue=deque((n,0) for n in selected)
while queue and len(selected)<a.limit:
 nid,depth=queue.popleft()
 if depth>=2:continue
 for nxt in sorted(adj[nid],key=lambda n:len(q&terms(nodes[n].get('label',''))),reverse=True):
  if nxt in selected:continue
  selected.add(nxt);queue.append((nxt,depth+1))
  if len(selected)>=a.limit:break
out=[]
for nid in sorted(selected,key=lambda n:(-len(q&terms(nodes[n].get('label',''))),nodes[n].get('label',''))):
 n=dict(nodes[nid]);sf=n.get('source_file')
 if sf:n['resolved_source_file']=str(root/sf);n['source_exists']=(root/sf).is_file()
 out.append(n)
print(json.dumps({'question':a.question,'source_root':str(root),'note':'Graph retrieval is context for the AI, not a generated answer. Read cited local pages before precise claims.','nodes':out,'relationships':[e for e in edges if e['source'] in selected and e['target'] in selected]},indent=2,ensure_ascii=False))
